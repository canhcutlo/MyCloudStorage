java \
    -Xdock:name="Shimeji-ee" \
    -Xdock:icon=img/Shimeji/shime1.png \
    -Xmx1000m \
    -jar Shimeji-ee.jar
